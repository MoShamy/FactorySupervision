# Detection_factory_line > 2025-07-13 2:53pm
https://universe.roboflow.com/rana-djciu/detection_factory_line

Provided by a Roboflow user
License: CC BY 4.0

